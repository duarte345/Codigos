import java.util.Scanner;

public class Ex5 {
    public static void main(String[] args) {
        int opcao;
        do{
            int nLanc=300;
            Scanner scan = new Scanner(System.in);
            System.out.print("Bem-vindo ao lançador de dados\n\nSelecione uma opção:\n1 - Lançar 1 dado\n2 - Lançar 2 dados\n3 - Sair\n\n-> ");
            opcao=Integer.parseInt(scan.nextLine());
            switch (opcao){
                case 1:
                    System.out.print("Quantas vezes pretende lançar o dado?\n-> ");
                    nLanc=Integer.parseInt(scan.nextLine());
                    int[] dado = new int[13];
                    for(int i=0; i<nLanc; i++){
                        int d1= (int)(Math.random()*6)+1;
                        dado[d1]++;
                    }
                    for(int i=1; i<=6; i++){
                        System.out.print(""+i+": ");
                        for(int j=0; j<dado[i]; j++)
                            System.out.print("X");
                        System.out.println(" ("+dado[i]+")");
                    }
                break;
                case 2:
                    System.out.print("Quantas vezes pretende lançar o dado?\n-> ");
                    nLanc=Integer.parseInt(scan.nextLine());
                    int[] dado2 = new int[13];
                    for(int i=0; i<nLanc; i++){
                        int d1= (int)(Math.random()*6)+1;
                        int d2= (int)(Math.random()*6)+1;
                        dado2[d1+d2]++;
                    }
                    for(int i=2; i<=12; i++){
                        System.out.print(""+i+": ");
                            for(int j=0; j<dado2[i]; j++)
                                System.out.print("X");
                        System.out.println(" ("+dado2[i]+")");
                    }
                break;
                case 3:
                    System.exit(0);
                break;
                default:
                    System.out.println("\nOpção Inválida!\nTente novamente!");
                break;
            }
        }while(opcao!=3);
    }       
}      