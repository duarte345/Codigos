public class ex1 {
    public static void main(String[] args) {
        int inicio = 1;
        int fim = 50;

        while (inicio <= 50) {
            System.out.println(inicio + " " + fim);
            inicio++;
            fim--;
        }
    }
}
