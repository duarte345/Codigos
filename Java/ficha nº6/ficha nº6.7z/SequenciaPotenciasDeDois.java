public class SequenciaPotenciasDeDois {
    public static void main(String[] args) {
        for (int n = 0; n <= 10; n++) {
            int resultado = (int) Math.pow(2, n);
            System.out.println(resultado);
        }
    }
}
