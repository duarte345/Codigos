public class ContagemCrescente {

    public static void main(String[] args){
        int i;
        for (i=10; i<21; i++){
            System.out.println(""+i);
            
        }
    }
}