public class NumerosPares {
    public static void main(String[] args) {
        for (int i = 50; i <= 80; i++) {
            if (i % 2 == 0) {
                System.out.println(i);
            }
        }
    }
}
