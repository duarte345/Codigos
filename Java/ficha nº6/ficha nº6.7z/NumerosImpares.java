public class NumerosImpares {
    public static void main(String[] args) {
        for (int i = 80; i >= 50; i--) {
            if (i % 2 != 0) {
                System.out.println(i);
            }
        }
    }
}
