public class ContagemDecrescente {

    public static void main(String[] args){
        int i;
        for (i=20; i>9; i--){
            System.out.println(""+i);
            
        }
    }
}